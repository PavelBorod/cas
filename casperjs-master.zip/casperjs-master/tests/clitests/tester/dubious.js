/*eslint strict:0*/
casper.test.begin('dubious test', 2, function(test) {
    test.assert(true);
    test.done();
});
